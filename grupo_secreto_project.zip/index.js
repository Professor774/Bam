
    import React, { useState } from 'react';
    import ReactDOM from 'react-dom';

    function App() {
        const [senha, setSenha] = useState('');
        const [acessoPermitido, setAcessoPermitido] = useState(false);

        const verificarSenha = () => {
            if (senha === '458') {
                setAcessoPermitido(true);
            } else {
                alert('Senha incorreta!');
            }
        };

        if (!acessoPermitido) {
            return (
                <div>
                    <h2>Digite a senha para acessar:</h2>
                    <input
                        type="password"
                        value={senha}
                        onChange={(e) => setSenha(e.target.value)}
                    />
                    <button onClick={verificarSenha}>Entrar</button>
                </div>
            );
        }

        return (
            <div>
                <h2>Bem-vindo ao Grupo Secreto!</h2>
                <p>Aqui você pode enviar mensagens, fotos e vídeos.</p>
            </div>
        );
    }

    ReactDOM.render(<App />, document.getElementById('root'));
    