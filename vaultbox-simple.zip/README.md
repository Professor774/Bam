# VaultBox Simple
Projeto básico pronto para Firebase em tempo real.