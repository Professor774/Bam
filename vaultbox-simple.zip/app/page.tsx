
export default function Home() {
  return (
    <main style={{ padding: 20 }}>
      <h1>VaultBox</h1>
      <p>Interface pronta para Firebase em tempo real</p>
    </main>
  );
}
